﻿namespace Hecole.Mediator.Interfaces
{
    /// <summary>
    /// Marker for notifications (no response).
    /// </summary>
    public interface INotification { }
}
